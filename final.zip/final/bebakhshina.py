def print_small_num(inp):
   match inp:
        case 1:
            ret = "one"
        case 2:
            ret = "two"
        case 3:
            ret = "three"
        case 4:
            ret = "four"
        case 5:
            ret = "five"
        case 6:
            ret = "six"
        case 7:
            ret = "seven"
        case 8:
            ret = "eight"
        case 9:
            ret = "nine"
        case default:
            ret = ""
   return ret


def print_num(inp):
  temp1 = inp % 100
  temp2 = inp // 100;

  ret = ""
  if (temp1 < 10 and temp1 > 0):
    ret = print_small_num(temp1)
  elif (temp1 < 20 and temp1 > 9):
        match temp1:
          case 10:
            ret = "ten"
          case 11:
            ret = "eleven"
          case 12:
            ret = "twelve"
          case 13:
            ret = "thirteen"
          case 14:
            ret = "fourteen"
          case 15:
            ret = "fifteen"
          case 16:
            ret = "sixteen"
          case 17:
            ret = "seventeen"
          case 18:
            ret = "eighteen"
          case 19:
            ret = "nineteen"
          case default:
            ret = "error"
  elif (temp1 >= 20 and temp1 < 30):
    ret = "twenty " + print_small_num(temp1 % 10)
  elif (temp1 >= 30 and temp1 < 40):
    ret = "thirty " + print_small_num(temp1 % 10)
  elif (temp1 >= 40 and temp1 < 50):
    ret = "fourty " + print_small_num(temp1 % 10)
  elif (temp1 >= 50 and temp1 < 60):
    ret = "fifty " + print_small_num(temp1 % 10)
  elif (temp1 >= 60 and temp1 < 70):
    ret = "sixty " + print_small_num(temp1 % 10)
  elif (temp1 >= 70 and temp1 < 80):
    ret = "seventy" + print_small_num(temp1 % 10)
  elif (temp1 >= 80 and temp1 < 90):
    ret = "eighty " + print_small_num(temp1 % 10)
  elif (temp1 >= 90 and temp1 < 100):
    ret = "ninety " + print_small_num(temp1 % 10)

  if (temp2 >0):
    ret = print_small_num(temp2) + " hundreds " + ret

  return ret


num = int(input("Enter your number: "))
if (num == 0):
   print("zero")

else:
   final = ""

   arr = ["", "thousands", "milioons", "bilioons"]
   index = 0
   while num > 0:
       temp = num % 1000
       final = " " + print_num(temp) + " " + arr[index] + final
       num = num // 1000
       index = index + 1

   print(final)
